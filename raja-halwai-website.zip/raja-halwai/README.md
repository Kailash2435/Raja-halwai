# RAJA HALWAI website (React + Vite + Tailwind)

## Run locally
    npm install
    npm run dev        # http://localhost:5173
    npm run build      # production build in /dist

## Edit content
All text, services, areas and gallery items are in `src/data.js`.
Replace photos: copy files into `public/images/` and set `src: '/images/name.jpg'` (gallery) or `HERO_IMG`.

## Before going live
Replace `YOUR-DOMAIN.com` in `index.html`, `public/robots.txt`, `public/sitemap.xml`.
Replace `YOUR_VERIFICATION_CODE` with your Google Search Console tag.

## Deploy
Vercel: push to GitHub, Import Project, Framework "Vite" (build `npm run build`, output `dist`).
Netlify: same repo, build command `npm run build`, publish directory `dist`.
