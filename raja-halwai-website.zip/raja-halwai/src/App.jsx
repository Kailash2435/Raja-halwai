import { Header, Hero, About, Services, Why, Process, Gallery, Areas, CtaBand, Contact, Footer, FloatingWA } from './components/Sections'
import { Marquee, Stats, Loader, BackToTop } from './components/Motion'
export default function App() {
  return (<><Loader /><Header /><main><Hero /><Marquee /><Stats /><About /><Services /><Why /><Process /><Gallery /><Areas /><CtaBand /><Contact /></main><Footer /><BackToTop /><FloatingWA /></>)
}
