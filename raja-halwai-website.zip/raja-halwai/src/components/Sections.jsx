import { useState, useEffect } from 'react'
import { Menu, X, Phone, MessageCircle, Mail, MapPin, Star, Check } from 'lucide-react'
import { B, waLink, HERO_IMG, services, why, steps, customerArranges, areas, eventTypes, galleryCats, gallery } from '../data'
import { Button, Section, Icon, Img } from './ui'
import { Rotator, InstallButton, ScrollBar, Reveal, Stats, Mandala, Sparks, Marquee } from './Motion'

const nav = [['about', 'About'], ['services', 'Services'], ['why', 'Why Us'], ['process', 'How It Works'], ['gallery', 'Gallery'], ['areas', 'Areas'], ['contact', 'Contact']]

export function Header() {
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-40 bg-maroon-dark/95 backdrop-blur text-cream shadow"><ScrollBar />
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="flex items-center gap-2 font-display text-xl font-bold text-gold-light"><img src="/images/emblem.png" alt="" width="40" height="40" className="h-10 w-10 rounded-full ring-1 ring-gold/60" />{B.name}</a>
        <nav aria-label="Main" className="hidden gap-6 text-sm lg:flex">
          {nav.map(([id, l]) => <a key={id} href={`#${id}`} className="hover:text-gold-light">{l}</a>)}
        </nav>
        <div className="hidden items-center gap-3 lg:flex"><InstallButton /><Button href={B.tel} icon="Phone" className="!py-2">Call Now</Button></div>
        <button className="lg:hidden" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav aria-label="Mobile" className="flex flex-col gap-1 border-t border-white/10 px-5 pb-4 lg:hidden">
          {nav.map(([id, l]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)} className="py-2">{l}</a>)}
          <InstallButton className="mt-2" /><Button href={B.tel} icon="Phone" className="mt-2">Call Now</Button>
        </nav>
      )}
    </header>
  )
}

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-gradient-to-br from-maroon-dark via-maroon to-maroon-dark text-cream">
      {HERO_IMG && <img src={HERO_IMG} alt="RAJA HALWAI cooking team at work" className="absolute inset-0 h-full w-full object-cover opacity-30" />}
      <Mandala /><Sparks />
      <div className="absolute bottom-10 right-10 hidden lg:block hero-rise"><img src="/images/logo.jpg" alt="RAJA HALWAI – Professional Cooking Team logo" width="288" height="288" className="w-72 rounded-2xl shadow-2xl ring-1 ring-gold/50" /></div>
      <div className="relative mx-auto max-w-6xl px-5 py-20 md:py-32">
        <div className="max-w-3xl">
          <p className="hero-rise font-display text-lg italic text-gold-light">{B.tagline}</p>
          <h1 className="hero-rise d1 mt-4 font-display text-4xl font-bold leading-tight md:text-6xl">Professional Halwai & Cooking Services in Satna</h1>
          <p className="hero-rise d1 mt-3 font-display text-2xl md:text-3xl">Cooking team for <Rotator words={['Weddings', 'Barat', 'Birthday Parties', 'Family Functions', 'Religious Events', 'Large Gatherings']} /></p>
          <p className="hero-rise d2 mt-5 max-w-xl leading-relaxed opacity-90">20+ Years of Experience | Experienced Cooking Team | Wedding & Event Cooking Services</p>
          <div className="hero-rise d3 mt-8 flex flex-wrap gap-3">
            <Button href={B.tel} icon="Phone">Call Now</Button>
            <Button href={waLink()} variant="wa" icon="MessageCircle">WhatsApp Inquiry</Button>
            <Button href="#services" variant="outline">Explore Our Services</Button>
          </div>
        </div>
      </div>
    </section>
  )
}

export const About = () => (
  <Section id="about" title="Our Experience, Your Celebration">
    <div className="grid gap-10 md:grid-cols-2">
      <div className="space-y-4 leading-relaxed">
        <p>RAJA HALWAI is a family-run professional cooking service from Kotar, Satna, backed by more than 20 years of practical experience as halwai and cooks.</p>
        <p>We provide the experienced cooking team. You choose the menu and arrange the ingredients, gas, utensils and kitchen setup. Our team comes to your venue and cooks the menu you selected.</p>
      </div>
      <ul className="grid gap-3 sm:grid-cols-2">
        {['20+ years of experience', 'Experienced cooking team', 'Flexible team size', 'Customer-selected menu', 'Wedding and event cooking', "Service at the customer's venue"].map(t => (
          <li key={t} className="flex items-start gap-2 rounded-md border border-gold/40 bg-white/60 p-3 text-sm"><Check size={18} className="mt-0.5 shrink-0 text-maroon" />{t}</li>
        ))}
      </ul>
    </div>
  </Section>
)

export const Services = () => (
  <Section id="services" title="Our Services" sub="Please note: this is a cooking-team service. We do not supply ingredients, gas, utensils, decoration, tables, chairs or a full catering package.">
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {services.map((s, i) => (
        <Reveal key={s.title} delay={(i % 3) * 110} className="h-full"><article className="relative h-full flex flex-col overflow-hidden rounded-lg border border-gold/40 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md">
          <span aria-hidden="true" className="absolute right-4 top-3 z-10 font-display text-4xl font-bold text-gold-light/70">{String(i + 1).padStart(2, "0")}</span>
          <Img src="" alt={s.title} className="h-40 w-full" />
          <div className="flex flex-1 flex-col p-5">
            <Icon name={s.icon} className="icon-hover text-gold" size={22} />
            <h3 className="mt-2 font-display text-xl font-semibold text-maroon">{s.title}</h3>
            <p className="mt-2 flex-1 text-sm leading-relaxed">{s.text}</p>
            <Button href={waLink(`Namaste RAJA HALWAI, mujhe "${s.title}" ke baare mein jaankari chahiye.`)} variant="wa" icon="MessageCircle" className="mt-4">WhatsApp Inquiry</Button>
          </div>
        </article></Reveal>
      ))}
    </div>
  </Section>
)

export const Why = () => (
  <Section id="why" dark title="Why Choose RAJA HALWAI?">
    <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
      {why.map(([ic, t, d]) => (
        <div key={t} className="flex gap-4">
          <Icon name={ic} size={28} className="floaty shrink-0 text-gold-light" />
          <div><h3 className="font-display text-lg font-semibold">{t}</h3><p className="mt-1 text-sm opacity-85">{d}</p></div>
        </div>
      ))}
    </div>
  </Section>
)

export const Process = () => (
  <Section id="process" title="How Our Service Works">
    <ol className="grid gap-6 md:grid-cols-4">
      {steps.map((s, i) => (
        <li key={i} className="rounded-lg border border-gold/40 bg-white p-5 transition hover:-translate-y-1 hover:shadow-md">
          <span style={{ "--d2": `${i * 0.25}s` }} className="pop flex h-9 w-9 items-center justify-center rounded-full bg-maroon font-display font-bold text-gold-light">{i + 1}</span>
          <p className="mt-3 text-sm leading-relaxed">{s}</p>
        </li>
      ))}
    </ol>
    <div className="mt-10 rounded-lg border-2 border-gold bg-white p-6">
      <h3 className="font-display text-xl font-semibold text-maroon">What the customer arranges</h3>
      <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {customerArranges.map(c => <li key={c} className="flex gap-2 text-sm"><Check size={18} className="text-maroon" />{c}</li>)}
      </ul>
    </div>
  </Section>
)

export function Gallery() {
  const [cat, setCat] = useState('All'); const [sel, setSel] = useState(null)
  const items = gallery.filter(g => cat === 'All' || g.cat === cat)
  useEffect(() => { const k = e => e.key === 'Escape' && setSel(null); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [])
  return (
    <Section id="gallery" title="Gallery" sub="Photos from our events will be added here. Images shown as placeholders are not our actual work.">
      <div className="mb-6 flex flex-wrap gap-2" role="group" aria-label="Gallery categories">
        {galleryCats.map(c => (
          <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
            className={`rounded-full border px-4 py-1.5 text-sm ${cat === c ? 'border-maroon bg-maroon text-cream' : 'border-gold/60 bg-white'}`}>{c}</button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {items.map(g => (
          <button key={g.id} onClick={() => setSel(g)} aria-label={`View ${g.alt}`} className="overflow-hidden rounded-md">
            <Img src={g.src} alt={g.alt} className="aspect-square w-full transition hover:scale-105" />
          </button>
        ))}
      </div>
      {sel && (
        <div role="dialog" aria-modal="true" aria-label={sel.alt} onClick={() => setSel(null)} className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-5">
          <button aria-label="Close" className="absolute right-5 top-5 text-white"><X size={28} /></button>
          <Img src={sel.src} alt={sel.alt} className="max-h-[80vh] w-full max-w-3xl rounded-md aspect-video" />
        </div>
      )}
    </Section>
  )
}

export const Areas = () => (
  <Section id="areas" title="Service Areas" sub="We travel to your event venue. Availability for nearby areas depends on event requirements.">
    <div className="grid gap-8 md:grid-cols-2">
      <ul className="space-y-3">
        {areas.map(a => <li key={a} className="flex items-center gap-2"><MapPin size={18} className="text-maroon" />{a}</li>)}
      </ul>
      <div>
        <iframe title="RAJA HALWAI location, Kotar, Satna" src={B.mapEmbed} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-72 w-full rounded-lg border border-gold/50" />
        <a href={B.mapsUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-sm text-maroon underline">Open in Google Maps</a>
      </div>
    </div>
  </Section>
)

const empty = { name: '', phone: '', type: eventTypes[0], date: '', location: '', guests: '', menu: '', msg: '' }
export function Contact() {
  const [f, setF] = useState(empty)
  const set = k => e => setF({ ...f, [k]: e.target.value })
  const submit = e => {
    e.preventDefault()
    const m = `Namaste RAJA HALWAI,\nName: ${f.name}\nPhone: ${f.phone}\nEvent type: ${f.type}\nEvent date: ${f.date || '-'}\nEvent location: ${f.location || '-'}\nApprox. guests: ${f.guests || '-'}\nMenu / requirements: ${f.menu || '-'}\nMessage: ${f.msg || '-'}`
    window.open(waLink(m), '_blank', 'noopener')
  }
  const field = 'mt-1 w-full rounded-md border border-gold/60 bg-white px-3 py-2 text-sm'
  const L = ({ t, children }) => <label className="block text-sm font-medium">{t}{children}</label>
  return (
    <Section id="contact" title="Customer Inquiry" sub="Fill in the details and your message opens in WhatsApp, ready to send. Nothing is stored on this website.">
      <div className="grid gap-10 md:grid-cols-5">
        <div className="space-y-4 md:col-span-2">
          <a href={B.tel} className="flex items-center gap-3"><Phone className="text-maroon" />{B.phone}</a>
          <a href={`mailto:${B.email}`} className="flex items-center gap-3 break-all"><Mail className="text-maroon" />{B.email}</a>
          <p className="flex gap-3"><MapPin className="mt-1 shrink-0 text-maroon" />{B.address}</p>
          <Button href={waLink()} variant="wa" icon="MessageCircle">WhatsApp Inquiry</Button>
          <div><Button href={B.review} variant="maroon" icon="Star">Share Your Experience on Google</Button></div>
        </div>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2 md:col-span-3">
          <L t="Customer Name *"><input required className={field} value={f.name} onChange={set('name')} autoComplete="name" /></L>
          <L t="Phone Number *"><input required type="tel" inputMode="tel" className={field} value={f.phone} onChange={set('phone')} autoComplete="tel" /></L>
          <L t="Event Type"><select className={field} value={f.type} onChange={set('type')}>{eventTypes.map(t => <option key={t}>{t}</option>)}</select></L>
          <L t="Event Date"><input type="date" className={field} value={f.date} onChange={set('date')} /></L>
          <L t="Event Location"><input className={field} value={f.location} onChange={set('location')} /></L>
          <L t="Approximate Number of Guests"><input type="number" min="1" className={field} value={f.guests} onChange={set('guests')} /></L>
          <div className="sm:col-span-2"><L t="Menu / Requirements"><textarea rows="3" className={field} value={f.menu} onChange={set('menu')} /></L></div>
          <div className="sm:col-span-2"><L t="Additional Message"><textarea rows="2" className={field} value={f.msg} onChange={set('msg')} /></L></div>
          <button type="submit" className="inline-flex items-center justify-center gap-2 rounded-md bg-[#1FA855] px-5 py-3 font-semibold text-white hover:bg-[#178a45] sm:col-span-2">
            <MessageCircle size={18} aria-hidden="true" />Send Inquiry on WhatsApp
          </button>
        </form>
      </div>
    </Section>
  )
}

export const CtaBand = () => (
  <section className="bg-gradient-to-r from-maroon-dark via-maroon to-maroon-dark py-16 text-center text-cream">
    <Reveal className="mx-auto max-w-3xl px-5">
      <p className="font-display italic text-gold-light">{B.tagline}</p>
      <h2 className="mt-2 font-display text-3xl font-bold md:text-5xl">Let&rsquo;s Plan Your Event Together</h2>
      <p className="mt-3 opacity-85">Call or message us with your event date, guest count and menu.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button href={B.tel} icon="Phone">Call Now</Button>
        <Button href={waLink()} variant="wa" icon="MessageCircle">WhatsApp Inquiry</Button>
      </div>
    </Reveal>
  </section>
)

export const Footer = () => (
  <footer className="bg-maroon-dark text-cream">
    <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-4">
      <div className="md:col-span-2">
        <img src="/images/logo.jpg" alt="RAJA HALWAI logo" width="112" height="112" loading="lazy" className="mb-3 h-28 w-28 rounded-xl ring-1 ring-gold/40" />
        <p className="font-display text-2xl text-gold-light">{B.name}</p>
        <p className="text-sm">{B.desc}</p><p className="mt-1 text-sm italic">{B.tagline}</p>
        <p className="mt-4 max-w-sm text-sm opacity-80">Family-run cooking team from Kotar, Satna with 20+ years of experience. We provide the cooking team; ingredients, gas and utensils are arranged by the customer.</p>
      </div>
      <div><h3 className="font-display text-lg text-gold-light">Quick Links</h3>
        <ul className="mt-3 space-y-2 text-sm">{nav.map(([id, l]) => <li key={id}><a href={`#${id}`} className="hover:text-gold-light">{l}</a></li>)}</ul></div>
      <div><h3 className="font-display text-lg text-gold-light">Contact</h3>
        <ul className="mt-3 space-y-2 text-sm">
          <li><a href={B.tel} className="hover:text-gold-light">{B.phone}</a></li>
          <li className="break-all"><a href={`mailto:${B.email}`} className="hover:text-gold-light">{B.email}</a></li>
          <li>Kotar, Satna, Madhya Pradesh</li>
          <li><a href={B.review} target="_blank" rel="noopener noreferrer" className="hover:text-gold-light">Share Your Experience on Google</a></li>
        </ul></div>
    </div>
    <div className="border-t border-white/10 py-4 text-center text-xs opacity-70">&copy; {new Date().getFullYear()} RAJA HALWAI. All rights reserved.</div>
  </footer>
)

export const FloatingWA = () => (
  <a href={waLink()} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"
     className="pulse fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#1FA855] text-white shadow-lg hover:bg-[#178a45]">
    <MessageCircle aria-hidden="true" />
  </a>
)
