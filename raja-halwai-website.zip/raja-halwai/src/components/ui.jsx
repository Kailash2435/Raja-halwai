import { Reveal } from './Motion'
import { Camera, Phone, MessageCircle, Sparkles, Heart, Flame, Cake, Flower2, Users, ChefHat, Award, UtensilsCrossed, MapPin, Route, Star } from 'lucide-react'
const Icons = { Phone, MessageCircle, Sparkles, Heart, Flame, Cake, Flower2, Users, ChefHat, Award, UtensilsCrossed, MapPin, Route, Star }

export const Icon = ({ name, ...p }) => { const C = Icons[name] || Icons.Star; return <C aria-hidden="true" {...p} /> }

const styles = {
  gold: 'shine bg-gradient-to-b from-gold-light to-gold text-maroon-dark hover:brightness-105',
  wa: 'bg-[#1FA855] text-white hover:bg-[#178a45]',
  outline: 'border border-gold-light text-white hover:bg-white/10',
  maroon: 'bg-maroon text-cream hover:bg-maroon-dark',
}
export const Button = ({ href, variant = 'gold', icon, children, className = '', ...p }) => (
  <a href={href} className={`inline-flex items-center justify-center gap-2 rounded-md px-5 py-3 text-sm font-semibold transition ${styles[variant]} ${className}`}
     {...(href?.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})} {...p}>
    {icon && <Icon name={icon} size={18} />}{children}
  </a>
)

export const Section = ({ id, title, sub, dark, children }) => (
  <section id={id} className={`py-16 md:py-24 ${dark ? 'bg-maroon text-cream' : ''}`}>
    <div className="mx-auto max-w-6xl px-5">
      <h2 className={`font-display text-3xl md:text-4xl font-bold ${dark ? 'text-gold-light' : 'text-maroon'}`}>{title}</h2>
      <div className="mt-3 h-0.5 w-16 bg-gold" />
      {sub && <p className="mt-4 max-w-2xl leading-relaxed opacity-90">{sub}</p>}
      <Reveal className="mt-10">{children}</Reveal>
    </div>
  </section>
)

// Shows the real photo when `src` is set, otherwise a clearly-labelled placeholder.
export const Img = ({ src, alt, className = '' }) => src
  ? <img src={src} alt={alt} loading="lazy" className={`object-cover ${className}`} />
  : <div role="img" aria-label={`${alt} (placeholder)`} className={`flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-maroon to-maroon-dark text-gold-light/80 ${className}`}>
      <Camera size={28} aria-hidden="true" /><span className="text-xs">Photo placeholder</span>
    </div>
