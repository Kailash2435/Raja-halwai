import { useEffect, useRef, useState } from 'react'
import { ArrowUp } from 'lucide-react'
import { services } from '../data'

const useInView = () => {
  const ref = useRef(); const [v, setV] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el || !('IntersectionObserver' in window)) return setV(true)
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); io.disconnect() } }, { threshold: 0.15 })
    io.observe(el); return () => io.disconnect()
  }, [])
  return [ref, v]
}

export function Reveal({ children, delay = 0, className = '' }) {
  const [ref, v] = useInView()
  return <div ref={ref} style={{ '--d': `${delay}ms` }} className={`reveal ${v ? 'in' : ''} ${className}`}>{children}</div>
}

function Counter({ to, prefix = '', suffix = '', format }) {
  const [ref, v] = useInView(); const [n, setN] = useState(0)
  useEffect(() => {
    if (!v) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return setN(to)
    let raf, t0; const step = t => { t0 ??= t; const p = Math.min((t - t0) / 1600, 1); setN(Math.round(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(step) }
    raf = requestAnimationFrame(step); return () => cancelAnimationFrame(raf)
  }, [v, to])
  return <span ref={ref}>{prefix}{format ? n.toLocaleString('en-IN') : n}{suffix}</span>
}

export const Stats = () => (
  <section aria-label="Highlights" className="border-y border-gold/40 bg-white/70">
    <div className="mx-auto grid max-w-6xl gap-6 px-5 py-8 text-center md:grid-cols-3">
      <Reveal><p className="font-display text-4xl font-bold text-maroon"><Counter to={20} suffix="+" /></p><p className="mt-1 text-sm">Years of Experience</p></Reveal>
      <Reveal delay={120}><p className="font-display text-4xl font-bold text-maroon"><Counter to={1000} prefix="~" format /></p><p className="mt-1 text-sm">Guests: size of events we have handled</p></Reveal>
      <Reveal delay={240}><p className="font-display text-2xl font-bold leading-[2.5rem] text-maroon">Aapka Menu, Hamari Zimmedari!</p><p className="mt-1 text-sm">You choose it, we cook it</p></Reveal>
    </div>
  </section>
)

export const Mandala = () => (
  <svg aria-hidden="true" viewBox="0 0 200 200" className="mandala pointer-events-none absolute -right-24 -top-24 h-[28rem] w-[28rem] text-gold-light opacity-20" fill="none" stroke="currentColor" strokeWidth="1">
    {[...Array(12)].map((_, i) => <ellipse key={i} cx="100" cy="44" rx="11" ry="34" transform={`rotate(${i * 30} 100 100)`} />)}
    {[...Array(12)].map((_, i) => <circle key={'c' + i} cx="100" cy="22" r="3" transform={`rotate(${i * 30 + 15} 100 100)`} />)}
    <circle cx="100" cy="100" r="30" /><circle cx="100" cy="100" r="92" strokeDasharray="2 5" />
  </svg>
)

export const Sparks = () => (
  <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 bottom-0 h-full overflow-hidden">
    {[...Array(14)].map((_, i) => <span key={i} className="spark" style={{ left: `${(i * 7.3 + 4) % 96}%`, '--t': `${5 + (i % 4)}s`, '--dl': `${-i * 0.7}s`, '--x': `${(i % 2 ? 1 : -1) * (10 + i * 2)}px` }} />)}
  </div>
)

export const Kadhai = () => (
  <svg aria-hidden="true" viewBox="0 0 220 180" className="h-56 w-64 text-gold-light" fill="none">
    {[70, 110, 150].map((x, i) => <path key={x} className="steam" style={{ animationDelay: `${i * 0.9}s` }} d={`M${x} 70c-10-10 10-18 0-30s10-18 0-28`} stroke="currentColor" strokeWidth="3" strokeLinecap="round" opacity=".8" />)}
    <path d="M25 90h170c0 50-35 80-85 80S25 140 25 90Z" fill="currentColor" opacity=".9" />
    <path d="M10 90h30M180 90h30" stroke="currentColor" strokeWidth="8" strokeLinecap="round" />
    <path d="M45 105c20 30 110 30 130 0" stroke="#4A0A12" strokeWidth="3" opacity=".35" strokeLinecap="round" />
  </svg>
)

export const Marquee = () => {
  const items = [...services.map(s => s.title), 'Kotar', 'Satna', 'Rewa', 'Semariya', 'Birsinghpur']
  const row = items.map(t => <span key={t} className="mx-5 whitespace-nowrap">{t} <span className="text-gold">✦</span></span>)
  return (
    <div aria-hidden="true" className="overflow-hidden bg-maroon-dark py-3 text-sm text-gold-light">
      <div className="marquee flex w-max">{row}{row}</div>
    </div>
  )
}

export function ScrollBar() {
  const [p, setP] = useState(0)
  useEffect(() => {
    const f = () => { const h = document.documentElement; setP(h.scrollTop / ((h.scrollHeight - h.clientHeight) || 1)) }
    f(); window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f)
  }, [])
  return <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-0.5"><div className="h-full origin-left bg-gold-light" style={{ transform: `scaleX(${p})` }} /></div>
}

export function InstallButton({ className = '' }) {
  const [ev, setEv] = useState(null)
  useEffect(() => {
    const h = e => { e.preventDefault(); setEv(e) }
    window.addEventListener('beforeinstallprompt', h); return () => window.removeEventListener('beforeinstallprompt', h)
  }, [])
  if (!ev) return null
  return <button onClick={async () => { ev.prompt(); await ev.userChoice; setEv(null) }} className={`rounded-md border border-gold-light px-4 py-2 text-sm font-semibold text-gold-light hover:bg-white/10 ${className}`}>Install App</button>
}

export function Loader() {
  const [show, setShow] = useState(true)
  useEffect(() => { const t = setTimeout(() => setShow(false), 1100); return () => clearTimeout(t) }, [])
  return (
    <div aria-hidden="true" className={`fixed inset-0 z-[60] flex flex-col items-center justify-center bg-maroon-dark transition-opacity duration-500 ${show ? 'opacity-100' : 'pointer-events-none opacity-0'}`}>
      <img src="/images/logo.jpg" alt="" className="w-44 animate-pulse rounded-2xl" />
    </div>
  )
}

export function Rotator({ words }) {
  const [i, setI] = useState(0)
  useEffect(() => { const t = setInterval(() => setI(x => (x + 1) % words.length), 2200); return () => clearInterval(t) }, [words.length])
  return <span key={i} className="hero-rise inline-block text-gold-light">{words[i]}</span>
}

export function BackToTop() {
  const [on, setOn] = useState(false)
  useEffect(() => { const f = () => setOn(window.scrollY > 500); f(); window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f) }, [])
  return <a href="#top" aria-label="Back to top" className={`fixed bottom-24 right-5 z-40 flex h-10 w-10 items-center justify-center rounded-full bg-gold text-maroon-dark shadow transition ${on ? 'opacity-100' : 'pointer-events-none opacity-0'}`}><ArrowUp size={18} /></a>
}
