// ===== EDIT HERE: all business content lives in this file =====
export const B = {
  name: 'RAJA HALWAI', desc: 'Professional Cooking Team', tagline: 'Aapka Menu, Hamari Zimmedari!',
  phone: '+91 9993309469', tel: 'tel:+919993309469', wa: '919993309469', email: 'rajahalwai.kotar@gmail.com',
  address: 'ग्राम पोस्ट कोटर, जिला सतना, पशु चिकित्सालय के सामने, मध्य प्रदेश, भारत।',
  review: 'https://g.page/r/Ca6dYrWsUceREBM/review',
  mapsUrl: 'https://www.google.com/maps/place/Raja+Halwai/@24.6979206,80.9823828,17z/data=!3m1!4b1!4m6!3m5!1s0x3984879b362e7ecf:0x91c751acb5629dae!8m2!3d24.6979206!4d80.9823828!16s%2Fg%2F11p2prb78q',
  mapEmbed: 'https://www.google.com/maps?q=24.6979206,80.9823828&z=15&output=embed',
}
export const waLink = (msg = 'Namaste RAJA HALWAI, mujhe cooking team ke baare mein jaankari chahiye.') =>
  `https://wa.me/${B.wa}?text=${encodeURIComponent(msg)}`

// Put your photo in /public/images and set e.g. HERO_IMG = '/images/hero.jpg'
export const HERO_IMG = ''

export const services = [
  { icon: 'Sparkles', title: 'Wedding Cooking Services', text: 'Experienced halwai and cooks for your wedding menu, working at your venue.' },
  { icon: 'Heart', title: 'Marriage Function Cooking', text: 'Cooking for tilak, haldi, sagai and other marriage-related functions.' },
  { icon: 'Flame', title: 'Barat Cooking Services', text: 'A team that handles barat meals with the menu you choose.' },
  { icon: 'Cake', title: 'Birthday Party Cooking', text: 'Home-style and festive cooking for birthdays and small celebrations.' },
  { icon: 'Flower2', title: 'Religious & Family Functions', text: 'Pooja, katha, bhandara and family gatherings, prepared with care.' },
  { icon: 'Users', title: 'Large Gathering Cooking', text: 'Team size set to your guest count. We have handled events of about 1,000 people.' },
  { icon: 'ChefHat', title: 'Special Occasion Cooking', text: 'Tell us your occasion and menu; we will plan the cooking team around it.' },
]
export const why = [
  ['Award', '20+ Years of Experience', 'Practical halwai and cooking experience built over two decades.'],
  ['ChefHat', 'Experienced Halwai Team', 'A trained team that knows large-quantity cooking.'],
  ['Users', 'Flexible Team Size', 'We fit the number of cooks to your event and guest count.'],
  ['UtensilsCrossed', "Customer's Choice of Menu", 'You decide the menu. We cook it.'],
  ['MapPin', 'Event Venue Cooking', 'We come to your venue and cook on site.'],
  ['Route', 'Service Across Nearby Areas', 'Kotar, Satna, Rewa, Semariya, Birsinghpur and nearby.'],
]
export const steps = [
  'You contact us by call or WhatsApp.',
  'You share the event, guest count and menu.',
  'We discuss the team size and service charges.',
  'Our cooking team reaches your venue and prepares the menu using your arrangements.',
]
export const customerArranges = ['Vegetables and other ingredients', 'Gas and fuel', 'Cooking utensils', 'Equipment and kitchen setup', 'Other required materials']
export const areas = ['Kotar', 'Satna', 'Rewa', 'Semariya', 'Birsinghpur', 'Nearby areas, depending on event requirements']
export const eventTypes = ['Wedding', 'Marriage Function', 'Barat', 'Birthday Party', 'Religious / Family Function', 'Large Gathering', 'Other']

// Gallery: set src to '/images/your-photo.jpg' to replace a placeholder.
export const galleryCats = ['All', 'Wedding Cooking', 'Food Preparation', 'Halwai Team', 'Marriage Functions', 'Special Events']
export const gallery = [
  ['Wedding Cooking', 'Wedding cooking in progress'], ['Wedding Cooking', 'Large pots at a wedding venue'],
  ['Food Preparation', 'Sweets being prepared'], ['Food Preparation', 'Preparing the menu on site'],
  ['Halwai Team', 'RAJA HALWAI cooking team'], ['Halwai Team', 'Halwai at work'],
  ['Marriage Functions', 'Marriage function cooking'], ['Marriage Functions', 'Barat meal preparation'],
  ['Special Events', 'Religious event cooking'], ['Special Events', 'Large gathering cooking'],
].map(([cat, alt], i) => ({ id: i, cat, alt, src: '' }))
