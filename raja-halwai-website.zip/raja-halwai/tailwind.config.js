export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { maroon: { DEFAULT: '#6B0F1A', dark: '#4A0A12' }, gold: { DEFAULT: '#C9A227', light: '#E6C766' }, cream: '#FBF6EA', ink: '#2B2B2B' },
    fontFamily: { display: ['"Playfair Display"', 'Georgia', 'serif'], body: ['Poppins', 'system-ui', 'sans-serif'] }
  } },
  plugins: []
}
